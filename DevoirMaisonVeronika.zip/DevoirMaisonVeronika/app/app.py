from flask import Flask, render_template
from flask import request
import os
from flask import jsonify
import json 
from flask_cors import CORS  
from bokeh.plotting import figure
from bokeh.embed import components
from mysql.connector import connect, Error
from bokeh.palettes import Category20c
from bokeh.transform import cumsum
import pandas as pd
from math import pi


app = Flask(__name__, static_url_path='/static')

# # ici on spécifie le nom du dossier
# app.config["UPLOAD_FOLDER"] = 'files'
# # ici on crée ce dossier
# os.makedirs('files', exist_ok='True')


user_input = 'root'
password = 'root'
dbname = 'neologismes'

# on peut également se connecter à la base en même temps que l'on se connecte au serveur
try:
    # on obtient une variable connection de type MySQLConnection avec laquelle on peut intéragir avec le serveur
    connection = connect(
        host="localhost",
        user = user_input,
        password = password,
        database=dbname,
        charset='utf8'
       
    )
    print(connection)
# gestion de toutes erreurs de connection
except Error as e:
    print(e)





# le "/" indique la racine du chemin, c'est à dire la page de base
@app.route('/', methods=['GET'])
def home():
    return '''Base de données de néologismes russes
'''



@app.route('/api/v1/neologismes', methods=['GET'])
def api_neologismes_all():
    # Requête pour récupérer toute l'info de la table 'néologismes'> id, neologisme, commentaire
    query1 = 'SELECT * FROM neologismes'

    # Requête pour compter le nombre de néologismes par thème
    query2 = '''
        SELECT t.nom_theme, COUNT(*) as count
        FROM neologismes n
        JOIN info_neologismes i ON n.idNeologism = i.IdNeologism
        JOIN theme t ON i.idTheme = t.idTheme
        GROUP BY t.nom_theme
    '''
    # Requête pour compter le nombre de néologismes par partie du discours (POS)
    query3 = '''
        SELECT p.POS, COUNT(*) as count
        FROM neologismes n
        JOIN info_neologismes i ON n.idNeologism = i.IdNeologism
        JOIN pos p ON i.idPOS = p.idPOS
        GROUP BY p.POS
    '''
    with connection.cursor(dictionary=True) as cursor:
        cursor.execute(query1)
        results1 = cursor.fetchall()
        cursor.execute(query2)
        results2 = cursor.fetchall()
        cursor.execute(query3)
        results3 = cursor.fetchall()

    # Utilisez results2 pour créer le premier graphique
    x_theme = {row['nom_theme']: row['count'] for row in results2}

    # Conversion des données en une série pandas
    data_theme = pd.Series(x_theme).reset_index(name='value').rename(columns={'index': 'theme'})

    # Calcul des angles pour le graphique en secteurs
    data_theme['angle'] = data_theme['value'] / data_theme['value'].sum() * 2 * pi

    # Calcul des pourcentages
    data_theme['percentage'] = (data_theme['value'] / data_theme['value'].sum()) * 100

    # Génération de couleurs à partir de la palette Category20c
    data_theme['color'] = Category20c[len(x_theme)]

    # Création de l'objet figure pour le graphique en secteurs
    p_theme = figure(height=350, title="Diagramme du nombre de néologismes dans chaque catégorie thématique", toolbar_location=None,
            tools="hover", tooltips="@theme: @value (@percentage%)", x_range=(-0.5, 1.0))

    # Création des secteurs avec la fonction wedge de Bokeh
    p_theme.wedge(x=0, y=1, radius=0.4,
            start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
            line_color="white", fill_color='color', legend_field='theme', source=data_theme)

    # Configuration de l'axe
    p_theme.axis.axis_label = None
    p_theme.axis.visible = False

    # Désactivation des lignes de la grille
    p_theme.grid.grid_line_color = None

    # Transformation du graphique Bokeh en composants
    script_theme, div_theme = components(p_theme)

    # Utilisez results3 pour créer le deuxième graphique
    x_pos = {row['POS']: row['count'] for row in results3}

    # Conversion des données en une série pandas
    data_pos = pd.Series(x_pos).reset_index(name='value').rename(columns={'index': 'POS'})

    # Calcul des angles pour le graphique en secteurs
    data_pos['angle'] = data_pos['value'] / data_pos['value'].sum() * 2 * pi

    # Calcul des pourcentages
    data_pos['percentage'] = (data_pos['value'] / data_pos['value'].sum()) * 100

    # Génération de couleurs à partir de la palette Category20c
    data_pos['color'] = Category20c[len(x_pos)]

    # Création de l'objet figure pour le graphique en secteurs
    p_pos = figure(height=350, title="Répartition des néologismes par partie du discours", toolbar_location=None,
            tools="hover", tooltips="@POS: @value (@percentage%)", x_range=(-0.5, 1.0))

    # Création des secteurs avec la fonction wedge de Bokeh
    p_pos.wedge(x=0, y=1, radius=0.4,
            start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
            line_color="white", fill_color='color', legend_field='POS', source=data_pos)

    # Configuration de l'axe
    p_pos.axis.axis_label = None
    p_pos.axis.visible = False

    # Désactivation des lignes de la grille
    p_pos.grid.grid_line_color = None

    # Transformation du graphique Bokeh en composants
    script_pos, div_pos = components(p_pos)


    # On envoie des données dans HTML, y compris le script et le div du graphique
    return render_template('index.html', neologisms=results1, script=script_pos, div=div_pos, script_theme=script_theme, div_theme=div_theme)




# Requête pour récupérer toutes les données
@app.route('/api/v1/all_data', methods=['GET'])
def api_all_data():
    # Liste des tables de la base de données
    tables = ['neologismes', 'POS', 'theme', 'info_neologismes']
    all_data = {}

    for table in tables:
        query = f'SELECT * FROM {table}'
       
        with connection.cursor(dictionary=True) as cursor:
            cursor.execute(query)
            results = cursor.fetchall()
        all_data[table] = results 
    return jsonify(all_data)



# Requête pour récupérer le néologisme, le commentaire, le thème et la partie du discours correspondants à l'ID donné
@app.route('/api/v1/neologismes/<int:id>', methods=['GET'])
def api_neologisme_by_id(id):
    query = '''
        SELECT n.*, t.nom_theme, p.POS
        FROM neologismes n
        JOIN info_neologismes i ON n.idNeologism = i.IdNeologism
        JOIN theme t ON i.idTheme = t.idTheme
        JOIN pos p ON i.idPOS = p.idPOS
        WHERE n.idNeologism = %s
    '''
    with connection.cursor(dictionary=True) as cursor:
        cursor.execute(query, (id,))
        result = cursor.fetchone()

    if result:
        return jsonify(result)
    else:
        return jsonify({'error': 'Neologism not found'}), 404
    


# Requête pour récupérer toutes les parties du discours (POS)
@app.route('/api/v1/pos', methods=['GET'])
def api_pos_all():
    query = 'SELECT * FROM pos'
    with connection.cursor(dictionary=True) as cursor:
        cursor.execute(query)
        results = cursor.fetchall()

    return jsonify(results)


# Requête pour récupérer tous les thèmes
@app.route('/api/v1/theme', methods=['GET'])
def api_theme_all():
    query = 'SELECT * FROM theme'
    with connection.cursor(dictionary=True) as cursor:
        cursor.execute(query)
        results = cursor.fetchall()

    return jsonify(results)


# Requête pour récupérer toutes les informations sur les néologismes du table 'info_neologismes'
@app.route('/api/v1/info_neologismes', methods=['GET'])
def api_info_neologismes_all():
    query = 'SELECT * FROM info_neologismes'
    with connection.cursor(dictionary=True) as cursor:
        cursor.execute(query)
        results = cursor.fetchall()

    return jsonify(results)



# Requête pour récupérer les néologismes par partie du discours (POS)
@app.route('/api/v1/neologismes/pos/<string:pos>', methods=['GET'])
def api_neologismes_by_pos(pos):
    query = '''
        SELECT n.*, t.nom_theme, p.POS
        FROM neologismes n
        JOIN info_neologismes i ON n.idNeologism = i.IdNeologism
        JOIN theme t ON i.idTheme = t.idTheme
        JOIN pos p ON i.idPOS = p.idPOS
        WHERE p.POS = %s
    '''
    with connection.cursor(dictionary=True) as cursor:
        cursor.execute(query, (pos,))
        results = cursor.fetchall()

    if results:
        return jsonify(results)
    else:
        return jsonify({'error': f'No neologisms found for POS: {pos}'}), 404


# Requête pour ajouter un nouveau néologisme
@app.route('/api/v1/neologismes', methods=['POST'])
def add_neologism():
    try:
        data = request.get_json()
        neologisme = data['neologisme']
        commentaire = data.get('commentaire', None)  # 'commentaire' n'est pas obligatoire
        
        insert_query = "INSERT INTO neologismes (neologisme, commentaire) VALUES (%s, %s)"
        with connection.cursor() as cursor:
            cursor.execute(insert_query, (neologisme, commentaire))
            connection.commit()

        return jsonify({'success': True, 'message': 'Néologisme ajouté avec succès'}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


 # Mise à jour de l'information sur un néologisme
@app.route('/api/v1/neologismes/<int:id>', methods=['PUT'])
def update_neologism(id):
    try:
        data = request.get_json()
        neologisme = data.get('neologisme')
        commentaire = data.get('commentaire', None)
       
        update_query = "UPDATE neologismes SET neologisme = %s, commentaire = %s WHERE idNeologism = %s"
        with connection.cursor() as cursor:
            cursor.execute(update_query, (neologisme, commentaire, id))
            connection.commit()

        return jsonify({'success': True, 'message': 'Informations sur le néologisme mises à jour avec succès'}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


# Supprimer un néologisme par un id
@app.route('/api/v1/neologismes/<int:id>', methods=['DELETE'])
def delete_neologism(id):
    
    delete_query = 'DELETE FROM neologismes WHERE idNeologism=%s'
    with connection.cursor() as cursor:
        cursor.execute(delete_query, (id,))
    connection.commit()

    return jsonify({'message': 'Neologisme est supprimé'})



# Gestionnaire d'erreur pour les réponses 404 (ressource non trouvée)
@app.errorhandler(404)
def page_not_found(e):
    return "<h1>404</h1><p>The resource could not be found.</p>", 404




if __name__ == '__main__':
    app.run(debug=True, port=5001)  # Используйте другой порт, если 5000 уже занят